#SoftWare: XCopy (old name: MiniXBackUp)
#Version: 2.0
#About this Program:
	Copy files between two different folders without repetitive operation.
#Programmer: Black C
#Development environment:
	java version "10.0.2" 2018-07-17
	Java(TM) SE Runtime Environment 18.3 (build 10.0.2+13)
	Java HotSpot(TM) 64-Bit Server VM 18.3 (build 10.0.2+13, mixed mode)

#Time: 2018/12/14